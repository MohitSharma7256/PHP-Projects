<?php

////	Peer Stopped
// The peer sent a "stopped" signal.
// The peer has been deleted.
