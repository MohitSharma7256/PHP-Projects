<?php

////	Peer Access
// A peer has announced their continued existence.
// The peers access time has been incremented to $time.
