<?php

////	Peer New
// An unrecognisable peer has arrived.
// The peer has been added to the index.
