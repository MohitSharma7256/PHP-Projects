### Phoenix (elementary OS)
2020-04-02 (v3.1.5)  
A modern fork of PeerTracker, a lightweight PHP/SQL BitTorrent Tracker.

---

### XBT
Updated June 2022
https://github.com/OlafvdSpek/xbt

### XBTIT [UNSECURE] (linuxtracker.org)
2020-10-03 (v3.1)  
https://github.com/btiteam/xbtit-3.1

### TorrentFlux B4RT [ABANDONED]
2014-06-09  
http://sourceforge.net/projects/tf-b4rt.berlios/

### TorrentFlux [ABANDONED]
2013-05-28 (v2.4)  
https://sourceforge.net/projects/torrentflux/

### phpMyBitTorrent [ABANDONED]
2013-04-29 (2.0.4repack)  
https://www.phpmybittorrent.com/  
http://sourceforge.net/projects/phpmybittorrent/

### TorrentFlux NG [PARTLY ABANDONED]
2011-06-14 (1.0)  
Developed 2015-09-10  
https://github.com/epsylon3/torrentflux

### RivetTracker [UNSECURE / ABANDONED] (previously Linux Mint @ https://torrents.linuxmint.com/)
2010-09-22 (1.03 with "Known Security Issues")  
http://www.rivetcode.com/ (mysql deprecated)  
http://sourceforge.net/projects/rivettracker/?source=directory  
RivetTracker is a modified version of PHPBTTracker. Written in PHP, this BitTorrent tracker uses MySQL as the database backend. It provides an RSS feed, optional support for HTTP seeding, detailed connection statistics, easy installation, and much more.
#### Blog Post - 2012-12-03 - 4:11 PM
After examining the general codebase, Rivettracker version 1.03 and all previous versions have security problems that need to be addressed. If you are running any of these versions, I recommend pulling the software and using an alternative tracker until these issues can be resolved. Downloads have been removed until this is fixed.

### PeerTracker [ABANDONED]
2010-01-23 (peertracker svn rev 164)  
https://en.wikipedia.org/wiki/PeerTracker  
https://github.com/JonnyJD/peertracker

### BitTornado [ABANDONED] (Ubuntu @ http://torrent.ubuntu.com:6969/)
2006-12-24 (v0.3.18)  
http://www.bittornado.com/

### PHPBTTracker+ [ABANDONED]
2006-11-28 (2.2)  
Version 2.x of PHPBTTracker+ is based off of the core of PHPBTTracker 1.5e, and supports peer caching and the compact protocol.  
http://phpbttrkplus.sourceforge.net/

### PHPBTTracker [ABANDONED]
2005-02-20 (1.5e)  
Bugfix release from 1.5b, and defective BEncode results.  
All of 1.5c and 1.5d is to be considered trash.  
http://dehacked.2y.net/BT/

